// UNTOLD - local Wi-Fi server. No dependencies, needs Node 18+.
// Run: GEMINI_API_KEY=xxx node server.js   (optional fallback: GROQ_API_KEY=xxx)
const http=require('http'),fs=require('fs'),path=require('path'),os=require('os'),crypto=require('crypto');
const PORT=process.env.PORT||3000,DATA=process.env.DATADIR||__dirname,FILE=path.join(DATA,'state.json'),KEYFILE=path.join(DATA,'gemini.key');
try{const k=fs.readFileSync(KEYFILE,'utf8').trim();if(k&&!process.env.GEMINI_API_KEY)process.env.GEMINI_API_KEY=k}catch(e){}
const TIERS=[['easy',15],['normal',13],['hard',12],['veryhard',9],['extreme',6],['impossible',5]];
const rnd=n=>crypto.randomBytes(n).toString('hex'),E=(m,c=400)=>Object.assign(new Error(m),{code:c});
const fresh=()=>({players:[],round:0,cur:null,last:null,msg:''});
let G=(()=>{try{const g=JSON.parse(fs.readFileSync(FILE));g.cur=null;return g}catch(e){return fresh()}})();
const save=()=>{try{fs.writeFileSync(FILE,JSON.stringify(G))}catch(e){}};
const clients=new Map();                                  // token -> Set(res)
const parts=()=>G.players.filter(p=>p.ready);
const online=p=>(clients.get(p.token)||{size:0}).size>0;
// What everybody may see. The secret and the 60 questions are never in here.
const pub=()=>({players:G.players.map(p=>({id:p.id,name:p.name,pts:p.pts,chip:p.chip,ready:p.ready,host:p.host,online:online(p)})),round:G.round,msg:G.msg,last:G.last,
 cur:G.cur&&{n:G.cur.n,phase:G.cur.phase,q:G.cur.q,remain:G.cur.qs?Object.fromEntries(TIERS.map(([k,c])=>[k,c-G.cur.drawn[k].length])):null}});
// What one player may see. The secret goes only to helpers, never to its owner.
const mine=p=>{const c=G.cur;return{id:p.id,host:p.host,secrets:p.secrets.map(s=>({id:s.id,text:s.text,evidence:s.evidence,ok:s.ok})),
 secret:c&&c.phase==='play'&&c.n!==p.id&&p.ready?c.secret:null}};
function broadcast(){const st=pub();for(const p of G.players)for(const r of clients.get(p.token)||[])r.write('data: '+JSON.stringify({state:st,me:mine(p)})+'\n\n')}
const parse=t=>JSON.parse(String(t).replace(/```json|```/g,'').trim());
async function ai(prompt){const errs=[];
 if(process.env.GEMINI_API_KEY){try{const m=process.env.GEMINI_MODEL||'gemini-2.5-flash';
  const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent?key=${process.env.GEMINI_API_KEY}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({contents:[{parts:[{text:prompt}]}],generationConfig:{responseMimeType:'application/json',temperature:0.7}})});
  const j=await r.json();if(!r.ok)throw Error(j.error&&j.error.message||r.status);return parse(j.candidates[0].content.parts[0].text)}catch(e){errs.push('gemini: '+e.message)}}
 if(process.env.GROQ_API_KEY){try{
  const r=await fetch('https://api.groq.com/openai/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+process.env.GROQ_API_KEY},body:JSON.stringify({model:process.env.GROQ_MODEL||'llama-3.3-70b-versatile',response_format:{type:'json_object'},messages:[{role:'user',content:prompt}]})});
  const j=await r.json();if(!r.ok)throw Error(j.error&&j.error.message||r.status);return parse(j.choices[0].message.content)}catch(e){errs.push('groq: '+e.message)}}
 throw E('هوش مصنوعی جواب نداد ('+(errs.join(' | ')||'هیچ کلیدی تنظیم نشده')+')',502)}
const pick=a=>a[Math.floor(Math.random()*a.length)];
async function route(name,b){const me=G.players.find(p=>p.token===b.token);
 const need=()=>{if(!me)throw E('اول وارد شو',401);return me},host=()=>{if(!need().host)throw E('فقط میزبان می‌تونه',403);return me};
 switch(name){
 case'join':{let p=me;if(!p){const nm=String(b.name||'').trim().slice(0,24);if(nm.length<2)throw E('اسم رو درست بنویس!',401);
   if(G.players.some(x=>x.name===nm))throw E('این اسم قبلاً هست!');
   p={id:rnd(4),token:rnd(16),name:nm,bio:'',secrets:[],ready:false,pts:0,chip:20,host:!G.players.length};G.players.push(p);save()}
  broadcast();return{token:p.token}}
 case'reset':{if(G.players.length&&!(me&&me.host))throw E('فقط میزبان می‌تونه بازی جدید بسازه',403);
  G=fresh();for(const s of clients.values())for(const r of s)r.end();clients.clear();save();return{}}
 case'analyze':{const p=need(),bio=String(b.bio||'').trim().slice(0,4000);if(bio.length<60)throw E('بیوگرافی خیلی کوتاهه؛ یکم بیشتر بنویس!');
  const r=await ai(`تو تحلیلگر بازی UNTOLD هستی. فقط و فقط از بیوگرافی زیر استفاده کن؛ هیچ چیز اختراع نکن و حدس رو حقیقت جا نزن. ۶ تا ۱۰ راز یا نکته جالب (شامل رابطه بین آدم‌ها، مکان‌ها و رویدادها) به فارسی غیررسمی و دوستانه استخراج کن. فقط JSON بده: {"secrets":[{"text":"...","evidence":"عبارت عینی از بیوگرافی","certain":true}]}. certain فقط وقتی true باشه که صراحتاً در متن اومده.\nبازیکن: ${p.name}\nبیوگرافی: ${bio}`);
  p.bio=bio;p.ready=false;p.secrets=(r.secrets||[]).filter(s=>s&&s.certain===true&&s.text&&s.evidence).map((s,j)=>({id:p.id+'-'+j,text:String(s.text).slice(0,300),evidence:String(s.evidence).slice(0,300),ok:true,used:false}));
  if(!p.secrets.length)throw E('رازی پیدا نشد؛ بیوگرافی رو کامل‌تر کن.');save();broadcast();return{}}
 case'approve':{const p=need(),ids=Array.isArray(b.ids)?b.ids:[];p.secrets.forEach(s=>s.ok=ids.includes(s.id));
  if(!p.secrets.some(s=>s.ok))throw E('حداقل یه راز باید تأیید بشه!');p.ready=true;save();broadcast();return{}}
 case'start':{host();const ps=parts();if(G.cur)throw E('یه دور در جریانه');if(ps.length<2)throw E('حداقل ۲ بازیکن آماده لازمه!');
  const n=ps[G.round%ps.length],pool=n.secrets.filter(s=>s.ok&&!s.used);G.msg='';
  if(!pool.length){G.msg='برای '+n.name+' راز تأییدشده‌ی استفاده‌نشده نمونده؛ بیوگرافی رو دوباره تحلیل کنه.';broadcast();return{}}
  const s=pick(pool);G.cur={n:n.id,sid:s.id,secret:s.text,qs:null,drawn:Object.fromEntries(TIERS.map(t=>[t[0],[]])),q:null,phase:'prep'};broadcast();
  (async()=>{try{let qs=null;for(let a=0;a<3&&!qs;a++){
   const r=await ai(`برای بازی UNTOLD دقیقاً ۶۰ سؤال فارسی غیررسمی و دوستانه بساز که به صاحب راز کمک کنه رازش رو حدس بزنه، بدون اینکه مستقیم لو بره. فقط بر اساس اطلاعات واقعی همین بیوگرافی و راز؛ چیزی اختراع نکن. سؤال‌ها بله/خیر یا سرنخ‌دار باشن (مثل «آیا این شخص در تهران زندگی می‌کنه؟»). سطح‌ها: easy:15 (کلی)، normal:13، hard:12، veryhard:9، extreme:6، impossible:5 (خیلی دقیق). فقط JSON با کلیدهای easy,normal,hard,veryhard,extreme,impossible و آرایه‌ی رشته‌ها.\nراز: ${s.text}\nشاهد: ${s.evidence}\nبیوگرافی ${n.name}: ${n.bio}`);
   if(TIERS.every(([k,c])=>Array.isArray(r[k])&&r[k].length>=c)){qs={};TIERS.forEach(([k,c])=>qs[k]=r[k].slice(0,c).map(String))}}
   if(!qs)throw Error('سؤال‌ها کامل نشد');if(!G.cur)return;G.cur.qs=qs;G.cur.phase='play'}
   catch(e){G.cur=null;G.msg='ساخت سؤال‌ها نشد: '+e.message}broadcast()})();return{}}
 case'draw':{const p=need(),c=G.cur;if(!c||c.phase!=='play'||c.n!==p.id)throw E('الان نوبت تو نیست',403);
  const k=b.tier;if(!c.drawn[k])throw E('سطح نامعتبر');const left=c.qs[k].map((_,i)=>i).filter(i=>!c.drawn[k].includes(i));
  if(!left.length)throw E('سؤال این سطح تموم شد!');const i=pick(left);c.drawn[k].push(i);c.q=c.qs[k][i];broadcast();return{}}
 case'verdict':{host();const c=G.cur;if(!c||c.phase!=='play')throw E('دور در جریان نیست');const f=!!b.found;
  const rows=parts().map(p=>{const b0=p.chip,own=p.id===c.n;let dp=0;if(f)dp=own?1:2;else p.chip=Math.max(0,p.chip-(own?2:1));p.pts+=dp;return{name:p.name,dp,dc:p.chip-b0}});
  const n=G.players.find(p=>p.id===c.n),s=n.secrets.find(x=>x.id===c.sid);if(s)s.used=true;
  G.last={round:G.round,n:n.name,found:f,secret:c.secret,rows};G.cur=null;G.round++;G.msg='';save();broadcast();return{}}
 default:throw E('نامعتبر',404)}}
const priv=a=>/^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(a);
function lanIps(){const o=[];try{for(const l of Object.values(os.networkInterfaces()))for(const i of l||[])if(i.family==='IPv4'&&!i.internal)o.push(i.address)}catch(e){}return o}
const udpIp=t=>new Promise(r=>{let s;const done=v=>{try{s&&s.close()}catch(e){}r(v)};try{s=require('dgram').createSocket('udp4');s.on('error',()=>done(null));setTimeout(()=>done(null),800);s.connect(80,t,()=>{try{done(s.address().address)}catch(e){done(null)}})}catch(e){done(null)}});
async function infoIps(){const s=new Set(lanIps());for(const t of['8.8.8.8','192.168.1.1'])s.add(await udpIp(t));return[...s].filter(a=>a&&priv(a))}
const json=(res,c,o)=>{res.writeHead(c,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(o))};
http.createServer((req,res)=>{const u=new URL(req.url,'http://x');
 res.setHeader('Access-Control-Allow-Origin','*');res.setHeader('Access-Control-Allow-Headers','Content-Type');
 if(req.method==='OPTIONS'){res.writeHead(204);return res.end()}
 const lo=['127.0.0.1','::1','::ffff:127.0.0.1'].includes(req.socket.remoteAddress);
 if(u.pathname==='/api/ping')return json(res,200,{ok:1});
 if(u.pathname==='/api/info'){infoIps().then(ips=>json(res,200,{ips,port:PORT}));return}
 if(req.method==='POST'&&u.pathname==='/api/setkey'){if(!lo)return json(res,403,{error:'فقط از خود گوشی میزبان'});let b='';req.on('data',c=>{b+=c;if(b.length>2000)req.destroy()});
  req.on('end',()=>{try{const k=String(JSON.parse(b).key||'').trim();if(k){process.env.GEMINI_API_KEY=k;try{fs.writeFileSync(KEYFILE,k)}catch(e){}}json(res,200,{ok:1})}catch(e){json(res,400,{error:'bad'})}});return}
 if(req.method==='GET'&&u.pathname==='/api/events'){const p=G.players.find(x=>x.token===u.searchParams.get('token'));if(!p){res.writeHead(401);return res.end()}
  res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache',Connection:'keep-alive'});
  if(!clients.has(p.token))clients.set(p.token,new Set());clients.get(p.token).add(res);
  const ka=setInterval(()=>res.write(': ka\n\n'),15000);res.on('close',()=>{clearInterval(ka);const s=clients.get(p.token);if(s){s.delete(res);if(!s.size)clients.delete(p.token)}broadcast()});broadcast();return}
 if(req.method==='GET'&&(u.pathname==='/'||u.pathname==='/index.html')){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});return res.end(fs.readFileSync(path.join(__dirname,'public','index.html')))}
 if(req.method==='GET'&&u.pathname==='/icon.png'){res.writeHead(200,{'Content-Type':'image/png','Cache-Control':'max-age=86400'});return res.end(fs.readFileSync(path.join(__dirname,'public','icon.png')))}
 if(req.method==='POST'&&u.pathname.startsWith('/api/')){let body='';req.on('data',c=>{body+=c;if(body.length>30000)req.destroy()});
  req.on('end',async()=>{let b={};try{b=JSON.parse(body||'{}')}catch(e){}try{json(res,200,await route(u.pathname.slice(5),b)||{})}catch(e){json(res,e.code||500,{error:e.message})}});return}
 res.writeHead(404);res.end()}).listen(PORT,'0.0.0.0',()=>{console.log('UNTOLD server is up. Open on every phone (same Wi-Fi):');
 try{for(const l of Object.values(os.networkInterfaces()))for(const i of l)if(i.family==='IPv4'&&!i.internal)console.log('  http://'+i.address+':'+PORT)}catch(e){console.log('  (could not list addresses - find your phone Wi-Fi IP in settings) port '+PORT)}console.log('  on this phone: http://localhost:'+PORT);
 if(!process.env.GEMINI_API_KEY&&!process.env.GROQ_API_KEY)console.log('WARNING: no GEMINI_API_KEY / GROQ_API_KEY set - AI features will fail.')});
