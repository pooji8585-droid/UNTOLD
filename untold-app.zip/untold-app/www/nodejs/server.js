// UNTOLD - local Wi-Fi server. No dependencies, needs Node 18+.
// Run: ANTHROPIC_API_KEY=xxx node server.js   (optional fallback: GROQ_API_KEY=xxx)
const http=require('http'),fs=require('fs'),path=require('path'),os=require('os'),crypto=require('crypto');
const PORT=process.env.PORT||3000,DATA=process.env.DATADIR||__dirname,FILE=path.join(DATA,'state.json'),KEYFILE=path.join(DATA,'claude.key'),GKEYFILE=path.join(DATA,'groq.key');
try{const k=fs.readFileSync(KEYFILE,'utf8').trim();if(k&&!process.env.ANTHROPIC_API_KEY)process.env.ANTHROPIC_API_KEY=k}catch(e){}
try{const k=fs.readFileSync(GKEYFILE,'utf8').trim();if(k&&!process.env.GROQ_API_KEY)process.env.GROQ_API_KEY=k}catch(e){}
const TIERS=['easy','normal','hard','veryhard','extreme','impossible'],MINQ=6,MAXQ=60;
const rnd=n=>crypto.randomBytes(n).toString('hex'),E=(m,c=400)=>Object.assign(new Error(m),{code:c});
const fresh=()=>({players:[],round:0,cur:null,last:null,msg:''});
let G=(()=>{try{const g=JSON.parse(fs.readFileSync(FILE));g.cur=null;return g}catch(e){return fresh()}})();
const save=()=>{try{fs.writeFileSync(FILE,JSON.stringify(G))}catch(e){}};
const clients=new Map();                                  // token -> Set(res)
const parts=()=>G.players.filter(p=>p.ready);
const online=p=>(clients.get(p.token)||{size:0}).size>0;
// What everybody may see. The secret and the 60 questions are never in here.
const pub=()=>({players:G.players.map(p=>({id:p.id,name:p.name,pts:p.pts,chip:p.chip,ready:p.ready,host:p.host,online:online(p)})),round:G.round,msg:G.msg,last:G.last,
 cur:G.cur&&{n:G.cur.n,phase:G.cur.phase,q:G.cur.q,lv:G.cur.lv,who:G.cur.who,wid:G.cur.wid,i:G.cur.i+1,total:G.cur.qs?G.cur.qs.length:0}});
// What one player may see. The secret goes only to helpers, never to its owner.
const mine=p=>{const c=G.cur;return{id:p.id,host:p.host,secrets:p.secrets.map(s=>({id:s.id,text:s.text,evidence:s.evidence,ok:s.ok})),
 secret:c&&c.phase==='play'&&c.n!==p.id&&p.ready?c.secret:null}};
function broadcast(){const st=pub();for(const p of G.players)for(const r of clients.get(p.token)||[])r.write('data: '+JSON.stringify({state:st,me:mine(p)})+'\n\n')}
const parse=t=>JSON.parse(String(t).replace(/```json|```/g,'').trim());
async function ai(prompt){const errs=[];
 if(process.env.ANTHROPIC_API_KEY){try{const m=process.env.CLAUDE_MODEL||'claude-sonnet-5-5';
  const r=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'Content-Type':'application/json','x-api-key':process.env.ANTHROPIC_API_KEY,'anthropic-version':'2023-06-01'},body:JSON.stringify({model:m,max_tokens:8192,temperature:0.7,system:'Reply with valid JSON only, no extra text or markdown.',messages:[{role:'user',content:prompt}]})});
  const j=await r.json();if(!r.ok)throw Error(j.error&&j.error.message||r.status);return parse(j.content.filter(c=>c.type==='text').map(c=>c.text).join(''))}catch(e){errs.push('claude: '+e.message)}}
 if(process.env.GROQ_API_KEY){const ms=process.env.GROQ_MODEL?[process.env.GROQ_MODEL]:['openai/gpt-oss-120b','openai/gpt-oss-20b','qwen/qwen3.6-27b'];
  for(const m of ms){try{
   const r=await fetch('https://api.groq.com/openai/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json','User-Agent':'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36',Authorization:'Bearer '+process.env.GROQ_API_KEY},body:JSON.stringify({model:m,response_format:{type:'json_object'},messages:[{role:'user',content:prompt}]})});
   const j=await r.json();if(!r.ok)throw Error(j.error&&j.error.message||r.status);return parse(j.choices[0].message.content)}catch(e){errs.push('groq('+m+'): '+e.message)}}}
 throw E('هوش مصنوعی جواب نداد ('+(errs.join(' | ')||'هیچ کلیدی تنظیم نشده')+')',502)}
const RULES=`تو هوش مصنوعی اختصاصی بازی UNTOLD هستی و بیوگرافی بازیکن‌ها رو تحلیل می‌کنی تا رازهای جالب برای بازی دربیاری.
قوانین:
۱. فقط از اطلاعاتی استفاده کن که بازیکن شخصاً در بیوگرافی خودش نوشته.
۲. هیچ اتفاق، رابطه یا اطلاعاتی از خودت نساز.
۳. اطلاعات نامطمئن رو به‌عنوان واقعیت بیان نکن.
۴. از اطلاعات حساس، خصوصی یا خطرناک راز نساز.
۵. رازها باید جالب، قابل حدس و مناسب فضای دوستانه‌ی بازی باشن.
۶. هر راز باید به یک بخش مشخص از بیوگرافی مستند باشه.
۷. همه‌ی خروجی‌ها فارسی باشن.
`;
const pick=a=>a[Math.floor(Math.random()*a.length)];
async function route(name,b){const me=G.players.find(p=>p.token===b.token);
 const need=()=>{if(!me)throw E('اول وارد شو',401);return me},host=()=>{if(!need().host)throw E('فقط میزبان می‌تونه',403);return me};
 switch(name){
 case'join':{let p=me;if(!p){const nm=String(b.name||'').trim().slice(0,24);if(nm.length<2)throw E('اسم رو درست بنویس!',401);
   if(G.players.some(x=>x.name===nm))throw E('این اسم قبلاً هست!');
   p={id:rnd(4),token:rnd(16),name:nm,bio:'',secrets:[],ready:false,pts:0,chip:20,host:!G.players.length};G.players.push(p);save()}
  broadcast();return{token:p.token}}
 case'reset':{if(G.players.length&&!(me&&me.host))throw E('فقط میزبان می‌تونه بازی جدید بسازه',403);
  G=fresh();for(const s of clients.values())for(const r of s)r.end();clients.clear();save();return{}}
 case'analyze':{const p=need(),bio=String(b.bio||'').trim().slice(0,4000);if(bio.length<60)throw E('بیوگرافی خیلی کوتاهه؛ یکم بیشتر بنویس!');
  const r=await ai(RULES+`وظیفه: ۶ تا ۱۰ راز یا نکته‌ی جالب (شامل رابطه بین آدم‌ها، مکان‌ها و رویدادها) از بیوگرافی زیر به فارسی غیررسمی و دوستانه استخراج کن. برای هر راز مدرک متنی و دلیل انتخاب هم بنویس. فقط JSON بده: {"secrets":[{"text":"راز پیشنهادی","evidence":"عبارت عینی از بیوگرافی","reason":"چرا این راز انتخاب شد","certain":true}]}. certain فقط وقتی true باشه که صراحتاً در متن اومده.\nبازیکن: ${p.name}\nبیوگرافی: ${bio}`);
  p.bio=bio;p.ready=false;p.secrets=(r.secrets||[]).filter(s=>s&&s.certain===true&&s.text&&s.evidence).map((s,j)=>({id:p.id+'-'+j,text:String(s.text).slice(0,300),evidence:String(s.evidence).slice(0,300),reason:String(s.reason||'').slice(0,300),ok:true,used:false}));
  if(!p.secrets.length)throw E('رازی پیدا نشد؛ بیوگرافی رو کامل‌تر کن.');save();broadcast();return{}}
 case'approve':{const p=need(),ids=Array.isArray(b.ids)?b.ids:[];p.secrets.forEach(s=>s.ok=ids.includes(s.id));
  if(!p.secrets.some(s=>s.ok))throw E('حداقل یه راز باید تأیید بشه!');p.ready=true;save();broadcast();return{}}
 case'start':{host();const ps=parts();if(G.cur)throw E('یه دور در جریانه');if(ps.length<2)throw E('حداقل ۲ بازیکن آماده لازمه!');
  const n=ps[G.round%ps.length],pool=n.secrets.filter(s=>s.ok&&!s.used);G.msg='';
  if(!pool.length){G.msg='برای '+n.name+' راز تأییدشده‌ی استفاده‌نشده نمونده؛ بیوگرافی رو دوباره تحلیل کنه.';broadcast();return{}}
  const s=pick(pool);G.cur={n:n.id,sid:s.id,secret:s.text,qs:null,i:-1,q:null,lv:null,who:null,wid:null,phase:'prep'};broadcast();
  (async()=>{try{let qs=null;for(let a=0;a<3&&!qs;a++){
   const r=await ai(RULES+`وظیفه: برای بازی UNTOLD سرنخ‌ها (به شکل سؤال) فارسی غیررسمی و دوستانه بساز که به بقیه کمک کنه راز رو حدس بزنن، بدون اینکه مستقیم لو بره. فقط بر اساس اطلاعات واقعی همین بیوگرافی و راز؛ چیزی اختراع نکن و از اطلاعات حساس یا خصوصی سرنخ نساز. سؤال‌ها بله/خیر یا سرنخ‌دار باشن (مثل «آیا این شخص در تهران زندگی می‌کنه؟»).\nتعداد سؤال‌ها رو خودت تعیین کن: بسته به اینکه بیوگرافی و راز چقدر اطلاعات واقعی دارن و چند نفر بازی می‌کنن (${ps.length} بازیکن، یعنی ${ps.length-1} کمک‌کننده). حداقل ${MINQ} و حداکثر ${MAXQ} سؤال؛ اطلاعات کم یعنی سؤال کمتر، اطلاعات زیاد یعنی سؤال بیشتر، ولی هیچ‌وقت برای پر کردن تعداد، چیزی اختراع نکن.\nسؤال‌ها باید دقیقاً از آسون به سخت مرتب باشن (اولی آسون‌ترین). سطح هر سؤال یکی از اینهاست: easy (کلی)، normal، hard، veryhard، extreme، impossible (خیلی دقیق). فقط JSON: {\"questions\":[{\"q\":\"متن سؤال\",\"level\":\"easy\"}]}\nراز: ${s.text}\nشاهد: ${s.evidence}\nبیوگرافی ${n.name}: ${n.bio}`);
   const arr=(Array.isArray(r.questions)?r.questions:[]).filter(x=>x&&typeof x.q==='string'&&x.q.trim()&&TIERS.includes(x.level)).map((x,j)=>({q:x.q.trim().slice(0,300),lv:x.level,j}));
   if(arr.length>=MINQ){arr.sort((x,y)=>TIERS.indexOf(x.lv)-TIERS.indexOf(y.lv)||x.j-y.j);qs=arr.slice(0,MAXQ).map(x=>({q:x.q,lv:x.lv}))}}
   if(!qs)throw Error('سؤال‌ها کامل نشد');if(!G.cur)return;G.cur.qs=qs;G.cur.phase='play'}
   catch(e){G.cur=null;G.msg='ساخت سؤال‌ها نشد: '+e.message}broadcast()})();return{}}
 case'draw':{const p=need(),c=G.cur;if(!c||c.phase!=='play'||c.n!==p.id)throw E('الان نوبت تو نیست',403);
  if(c.i+1>=c.qs.length)throw E('سؤال‌ها تموم شد! میزبان نتیجه‌ی دور رو ثبت کنه');
  c.i++;const it=c.qs[c.i],hs=parts().filter(x=>x.id!==c.n),w=hs.length?hs[c.i%hs.length]:null;
  c.q=it.q;c.lv=it.lv;c.who=w?w.name:null;c.wid=w?w.id:null;broadcast();return{}}
 case'verdict':{host();const c=G.cur;if(!c||c.phase!=='play')throw E('دور در جریان نیست');const f=!!b.found;
  const rows=parts().map(p=>{const b0=p.chip,own=p.id===c.n;let dp=0;if(f)dp=own?1:2;else p.chip=Math.max(0,p.chip-(own?2:1));p.pts+=dp;return{name:p.name,dp,dc:p.chip-b0}});
  const n=G.players.find(p=>p.id===c.n),s=n.secrets.find(x=>x.id===c.sid);if(s)s.used=true;
  G.last={round:G.round,n:n.name,found:f,secret:c.secret,rows};G.cur=null;G.round++;G.msg='';save();broadcast();return{}}
 default:throw E('نامعتبر',404)}}
const priv=a=>/^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(a);
function lanIps(){const o=[];try{for(const l of Object.values(os.networkInterfaces()))for(const i of l||[])if(i.family==='IPv4'&&!i.internal)o.push(i.address)}catch(e){}return o}
const udpIp=t=>new Promise(r=>{let s;const done=v=>{try{s&&s.close()}catch(e){}r(v)};try{s=require('dgram').createSocket('udp4');s.on('error',()=>done(null));setTimeout(()=>done(null),800);s.connect(80,t,()=>{try{done(s.address().address)}catch(e){done(null)}})}catch(e){done(null)}});
async function infoIps(){const s=new Set(lanIps());for(const t of['8.8.8.8','192.168.1.1'])s.add(await udpIp(t));return[...s].filter(a=>a&&priv(a))}
const json=(res,c,o)=>{res.writeHead(c,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(o))};
http.createServer((req,res)=>{const u=new URL(req.url,'http://x');
 res.setHeader('Access-Control-Allow-Origin','*');res.setHeader('Access-Control-Allow-Headers','Content-Type');
 if(req.method==='OPTIONS'){res.writeHead(204);return res.end()}
 const lo=['127.0.0.1','::1','::ffff:127.0.0.1'].includes(req.socket.remoteAddress);
 if(u.pathname==='/api/ping')return json(res,200,{ok:1});
 if(u.pathname==='/api/info'){infoIps().then(ips=>json(res,200,{ips,port:PORT}));return}
 if(u.pathname==='/api/keystatus'){if(!lo)return json(res,403,{error:'فقط از خود گوشی میزبان'});const k=process.env.ANTHROPIC_API_KEY||process.env.GROQ_API_KEY||'';return json(res,200,{set:!!k,tail:k?k.slice(-4):'',kind:process.env.ANTHROPIC_API_KEY?'Claude':process.env.GROQ_API_KEY?'Groq':''})}
 if(req.method==='POST'&&(u.pathname==='/api/setkey'||u.pathname==='/api/testkey')){if(!lo)return json(res,403,{error:'فقط از خود گوشی میزبان'});let b='';req.on('data',c=>{b+=c;if(b.length>2000)req.destroy()});
  req.on('end',async()=>{try{const d=JSON.parse(b||'{}');
   if(u.pathname==='/api/testkey'){try{await ai('فقط این JSON رو برگردون: {"ok":true}');json(res,200,{ok:1})}catch(e){json(res,200,{ok:0,error:e.message})}return}
   if(d.clear){delete process.env.ANTHROPIC_API_KEY;delete process.env.GROQ_API_KEY;try{fs.unlinkSync(KEYFILE)}catch(e){}try{fs.unlinkSync(GKEYFILE)}catch(e){}}
   else{const k=String(d.key||'').trim();if(k.length<10)throw Error('bad');
    if(k.startsWith('gsk_')){process.env.GROQ_API_KEY=k;try{fs.writeFileSync(GKEYFILE,k)}catch(e){}}
    else{process.env.ANTHROPIC_API_KEY=k;try{fs.writeFileSync(KEYFILE,k)}catch(e){}}}
   json(res,200,{ok:1})}catch(e){json(res,400,{error:'کلید معتبر نیست'})}});return}
 if(req.method==='GET'&&u.pathname==='/api/events'){const p=G.players.find(x=>x.token===u.searchParams.get('token'));if(!p){res.writeHead(401);return res.end()}
  res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache',Connection:'keep-alive'});
  if(!clients.has(p.token))clients.set(p.token,new Set());clients.get(p.token).add(res);
  const ka=setInterval(()=>res.write(': ka\n\n'),15000);res.on('close',()=>{clearInterval(ka);const s=clients.get(p.token);if(s){s.delete(res);if(!s.size)clients.delete(p.token)}broadcast()});broadcast();return}
 if(req.method==='GET'&&(u.pathname==='/'||u.pathname==='/index.html')){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});return res.end(fs.readFileSync(path.join(__dirname,'public','index.html')))}
 if(req.method==='GET'){const mm=u.pathname.match(/^\/([\w-]+\.(png|webp|jpg))$/);if(mm){try{const f=fs.readFileSync(path.join(__dirname,'public',mm[1]));res.writeHead(200,{'Content-Type':{png:'image/png',jpg:'image/jpeg',webp:'image/webp'}[mm[2]],'Cache-Control':'max-age=86400'});return res.end(f)}catch(e){res.writeHead(404);return res.end()}}}
 if(req.method==='POST'&&u.pathname.startsWith('/api/')){let body='';req.on('data',c=>{body+=c;if(body.length>30000)req.destroy()});
  req.on('end',async()=>{let b={};try{b=JSON.parse(body||'{}')}catch(e){}try{json(res,200,await route(u.pathname.slice(5),b)||{})}catch(e){json(res,e.code||500,{error:e.message})}});return}
 res.writeHead(404);res.end()}).listen(PORT,'0.0.0.0',()=>{console.log('UNTOLD server is up. Open on every phone (same Wi-Fi):');
 try{for(const l of Object.values(os.networkInterfaces()))for(const i of l)if(i.family==='IPv4'&&!i.internal)console.log('  http://'+i.address+':'+PORT)}catch(e){console.log('  (could not list addresses - find your phone Wi-Fi IP in settings) port '+PORT)}console.log('  on this phone: http://localhost:'+PORT);
 if(!process.env.ANTHROPIC_API_KEY&&!process.env.GROQ_API_KEY)console.log('WARNING: no ANTHROPIC_API_KEY / GROQ_API_KEY set - AI features will fail.')});
