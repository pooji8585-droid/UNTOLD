// Adds the camera permission to the Android project (needed for the QR scanner).
// Run once after `npx cap add android` / `npx cap sync android`, before building the APK:
//   node add-camera-permission.js
const fs = require('fs'), path = require('path');
const f = path.join(__dirname, 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
if (!fs.existsSync(f)) { console.log('AndroidManifest.xml not found at ' + f); process.exit(1); }
let x = fs.readFileSync(f, 'utf8');
const add = [];
if (!/android\.permission\.CAMERA/.test(x)) add.push('    <uses-permission android:name="android.permission.CAMERA" />');
if (!/android\.hardware\.camera"/.test(x)) add.push('    <uses-feature android:name="android.hardware.camera" android:required="false" />');
if (!add.length) { console.log('Camera permission already present.'); process.exit(0); }
x = x.replace(/<\/manifest>\s*$/, add.join('\n') + '\n</manifest>\n');
fs.writeFileSync(f, x);
console.log('Added:\n' + add.join('\n'));
